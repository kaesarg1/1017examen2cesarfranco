<template>
  <div id="header">
    <nav class="navbar">
      <span class="navbar-brand">Cesar Franco - Examen 2</span>
        <ul class="navbar-nav mr-auto">
          <li class="nav-item" v-for="menu in menuItems" :key="menu.id">
            <router-link :to="{path:menu.name}" class="nav-link">{{menu.name}}</router-link>
           
          </li>
        </ul>
    </nav>
  </div>
</template>

<script>

export default {
  name: 'Header',
  data() {
      return {
        menuItems: [
          { 
            id: 1,
            name: "accueil",
            path: "/",
          },
          { 
            id: 2,
            name: "projets",
            path: "/Projets",
          },
          { 
            id: 3,
            name: "contact",
            path: "/Contact",
          }
        ]
      }

  }
}
</script>

<style scoped>

.navbar {
  margin-bottom: 30px;
}
li{
  display: inline-block;
}
</style>