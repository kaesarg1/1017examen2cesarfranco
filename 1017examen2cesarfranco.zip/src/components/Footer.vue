<template>
    <div class="footer">
        <h1>Footer</h1>
    </div>
</template>

<script>

export default {
  name: 'Footer',


}
</script>

<style>

</style>